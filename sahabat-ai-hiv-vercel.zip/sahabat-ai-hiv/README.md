# SAHABAT AI HIV 🎀

Aplikasi kesehatan berbasis AI untuk edukasi, skrining risiko, dan informasi HIV/AIDS yang privat, aman, dan gratis.

## Fitur Utama
- 🤖 **AI Chatbot 24/7** - Powered by Claude AI (Anthropic)
- ✅ **Self-Screening Risiko HIV** - 7 pertanyaan tervalidasi
- 📚 **Materi Edukasi Interaktif** - Literasi HIV lengkap
- 📍 **Lokasi Tes HIV Terdekat** - Puskesmas, Klinik VCT, RS
- 🔒 **Privat & Aman** - Tanpa data pribadi
- 🎁 **100% Gratis**

## Deploy ke Vercel

### Opsi 1: Vercel CLI
\`\`\`bash
npm install -g vercel
cd sahabat-ai-hiv-app
npm install
vercel deploy
\`\`\`

### Opsi 2: GitHub + Vercel Dashboard
1. Push repo ini ke GitHub
2. Login ke [vercel.com](https://vercel.com)
3. Klik "New Project" → Import repo
4. Build Settings sudah otomatis dari `vercel.json`
5. Klik Deploy!

### Environment Variables (Opsional)
Aplikasi ini menggunakan Anthropic API secara langsung dari browser.
Untuk produksi, disarankan membuat backend proxy:
- Buat `/api/chat` endpoint di Vercel Functions
- Simpan `ANTHROPIC_API_KEY` di Vercel Environment Variables

## Pengembangan Lokal
\`\`\`bash
npm install
npm start
\`\`\`

Buka [http://localhost:3000](http://localhost:3000)

## Teknologi
- React 18
- Anthropic Claude API (claude-sonnet-4-20250514)
- Vercel (hosting)
- Google Fonts (Plus Jakarta Sans)

## Struktur
\`\`\`
src/
  pages/
    HomePage.js      # Beranda dengan 4 fitur utama
    ChatPage.js      # AI Chatbot HIV
    ScreeningPage.js # Self-Screening 7 pertanyaan
    LiterasiPage.js  # Materi edukasi HIV
    LokasiPage.js    # Cari tempat tes HIV
    OtherPages.js    # Riwayat, Notifikasi, Profil
  App.js             # Navigasi utama
  index.js           # Entry point
  index.css          # Global styles
\`\`\`

---
**SAHABAT AI HIV** – Cek Risiko, Kenali Diri, Lindungi Masa Depan 💜
