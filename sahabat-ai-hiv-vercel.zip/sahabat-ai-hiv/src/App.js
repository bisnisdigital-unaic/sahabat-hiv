import React, { useState } from 'react';
import HomePage from './pages/HomePage';
import ChatPage from './pages/ChatPage';
import ScreeningPage from './pages/ScreeningPage';
import LiterasiPage from './pages/LiterasiPage';
import LokasiPage from './pages/LokasiPage';
import ProfilePage from './pages/ProfilePage';
import HistoryPage from './pages/HistoryPage';
import NotifPage from './pages/NotifPage';

const NavIcon = ({ type, active }) => {
  const color = active ? '#7C3AED' : '#9CA3AF';
  if (type === 'home') return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill={active ? color : 'none'} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/>
    </svg>
  );
  if (type === 'history') return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/>
    </svg>
  );
  if (type === 'notif') return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill={active ? color : 'none'} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>
    </svg>
  );
  if (type === 'profile') return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill={active ? color : 'none'} stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
    </svg>
  );
  return null;
};

export default function App() {
  const [activePage, setActivePage] = useState('home');
  const [subPage, setSubPage] = useState(null);

  const navigate = (page, sub = null) => {
    setSubPage(sub);
    if (['home', 'history', 'notif', 'profile'].includes(page)) {
      setActivePage(page);
    } else {
      setSubPage(page);
    }
  };

  const goBack = () => {
    setSubPage(null);
  };

  const renderPage = () => {
    if (subPage === 'chat') return <ChatPage onBack={goBack} />;
    if (subPage === 'screening') return <ScreeningPage onBack={goBack} />;
    if (subPage === 'literasi') return <LiterasiPage onBack={goBack} />;
    if (subPage === 'lokasi') return <LokasiPage onBack={goBack} />;

    switch (activePage) {
      case 'home': return <HomePage onNavigate={navigate} />;
      case 'history': return <HistoryPage />;
      case 'notif': return <NotifPage />;
      case 'profile': return <ProfilePage />;
      default: return <HomePage onNavigate={navigate} />;
    }
  };

  const showNav = !subPage;
  const navItems = [
    { key: 'home', label: 'Beranda' },
    { key: 'history', label: 'Riwayat' },
    { key: 'notif', label: 'Notifikasi' },
    { key: 'profile', label: 'Profil' },
  ];

  return (
    <div style={{
      width: '100%',
      maxWidth: 430,
      minHeight: '100vh',
      background: '#fff',
      display: 'flex',
      flexDirection: 'column',
      position: 'relative',
      boxShadow: '0 0 40px rgba(0,0,0,0.15)',
    }}>
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: showNav ? 72 : 0 }}>
        {renderPage()}
      </div>

      {showNav && (
        <nav style={{
          position: 'fixed',
          bottom: 0,
          width: '100%',
          maxWidth: 430,
          background: '#fff',
          borderTop: '1px solid #F3F4F6',
          display: 'flex',
          zIndex: 100,
          paddingBottom: 'env(safe-area-inset-bottom)',
        }}>
          {navItems.map(item => (
            <button
              key={item.key}
              onClick={() => setActivePage(item.key)}
              style={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 3,
                padding: '10px 0',
                background: 'none',
                cursor: 'pointer',
              }}
            >
              <NavIcon type={item.key} active={activePage === item.key && !subPage} />
              <span style={{
                fontSize: 11,
                fontWeight: activePage === item.key && !subPage ? 600 : 400,
                color: activePage === item.key && !subPage ? '#7C3AED' : '#9CA3AF',
                fontFamily: 'var(--font)',
              }}>{item.label}</span>
            </button>
          ))}
        </nav>
      )}
    </div>
  );
}
