import React, { useState, useRef, useEffect } from 'react';

const SYSTEM_PROMPT = `Kamu adalah SAHABAT AI HIV, asisten kesehatan yang ramah dan berpengetahuan tentang HIV/AIDS. Kamu berbicara dalam Bahasa Indonesia yang santai dan mudah dipahami remaja.

PANDUAN:
- Jawab pertanyaan tentang HIV dengan akurat berdasarkan sains terkini
- Gunakan bahasa yang ramah, tidak menghakimi, dan mudah dipahami
- Jika ada pertanyaan medis serius, sarankan untuk konsultasi dokter atau fasilitas kesehatan
- Jaga privasi dan rahasiakan semua informasi pengguna
- Berikan fakta, bukan mitos tentang HIV
- Selalu dukung dan empati kepada pengguna
- Jangan lebih dari 150 kata per jawaban kecuali diperlukan
- Format jawaban dengan paragraf singkat, bisa gunakan bullet points jika perlu

Topik yang bisa kamu bantu:
- Cara penularan HIV dan pencegahannya
- Gejala dan diagnosis HIV
- Pengobatan ARV (Antiretroviral)
- Tes HIV - kapan dan di mana
- Hidup sehat dengan HIV
- PrEP dan PEP
- Mitos vs fakta HIV
- Dukungan psikososial`;

const SUGGESTED_QUESTIONS = [
  'Cara Pencegahan HIV',
  'Gejala HIV',
  'Kapan harus tes HIV?',
  'Apa itu PrEP?',
  'Apakah HIV bisa sembuh?',
];

const RobotAvatar = () => (
  <div style={{
    width: 36, height: 36, borderRadius: '50%',
    background: 'linear-gradient(135deg, #7C3AED, #9F67F7)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    flexShrink: 0,
  }}>
    <span style={{ fontSize: 18 }}>🤖</span>
  </div>
);

const TypingIndicator = () => (
  <div style={{ display: 'flex', gap: 4, padding: '12px 16px' }}>
    {[0, 1, 2].map(i => (
      <div key={i} style={{
        width: 8, height: 8, borderRadius: '50%',
        background: '#7C3AED',
        animation: `bounce 1.2s ${i * 0.2}s infinite`,
      }} />
    ))}
    <style>{`@keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }`}</style>
  </div>
);

export default function ChatPage({ onBack }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hai! 👋\nAku Sahabat AI HIV.\nAda yang ingin kamu tanyakan tentang HIV?',
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput('');

    const userMsg = {
      role: 'user',
      content: msg,
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setLoading(true);

    try {
      const apiMessages = newMessages.map(m => ({ role: m.role, content: m.content }));
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: apiMessages,
        }),
      });
      const data = await response.json();
      const reply = data.content?.[0]?.text || 'Maaf, aku tidak bisa menjawab saat ini. Coba lagi ya!';
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: reply,
        time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      }]);
    } catch {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Maaf, ada masalah koneksi. Coba lagi ya! 🙏',
        time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      }]);
    }
    setLoading(false);
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: '#F9FAFB' }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #7C3AED, #9F67F7)',
        padding: '48px 16px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
      }}>
        <button onClick={onBack} style={{
          background: 'rgba(255,255,255,0.2)', border: 'none', borderRadius: 10,
          padding: '8px 10px', cursor: 'pointer',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <RobotAvatar />
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#fff' }}>Chat AI HIV</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)' }}>● Online • Selalu tersedia</div>
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{
            display: 'flex',
            flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
            alignItems: 'flex-end',
            gap: 8,
          }}>
            {msg.role === 'assistant' && <RobotAvatar />}
            <div style={{ maxWidth: '78%' }}>
              <div style={{
                background: msg.role === 'user' ? 'linear-gradient(135deg, #7C3AED, #9F67F7)' : '#fff',
                color: msg.role === 'user' ? '#fff' : '#1F2937',
                borderRadius: msg.role === 'user' ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
                padding: '12px 14px',
                fontSize: 14,
                lineHeight: 1.6,
                boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                whiteSpace: 'pre-wrap',
              }}>
                {msg.content}
              </div>
              <div style={{
                fontSize: 11, color: '#9CA3AF', marginTop: 4,
                textAlign: msg.role === 'user' ? 'right' : 'left',
              }}>{msg.time}</div>
            </div>
          </div>
        ))}

        {loading && (
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
            <RobotAvatar />
            <div style={{
              background: '#fff', borderRadius: '18px 18px 18px 4px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
            }}>
              <TypingIndicator />
            </div>
          </div>
        )}

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
            {SUGGESTED_QUESTIONS.map((q, i) => (
              <button
                key={i}
                onClick={() => sendMessage(q)}
                style={{
                  background: '#fff', border: '1.5px solid #EDE9FE',
                  borderRadius: 20, padding: '8px 14px',
                  fontSize: 13, color: '#7C3AED', fontWeight: 600,
                  cursor: 'pointer', fontFamily: 'var(--font)',
                  transition: 'all 0.2s',
                }}
              >
                {q}
              </button>
            ))}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{
        background: '#fff',
        padding: '12px 16px',
        paddingBottom: 'calc(12px + env(safe-area-inset-bottom))',
        borderTop: '1px solid #F3F4F6',
        display: 'flex',
        gap: 10,
        alignItems: 'center',
      }}>
        <input
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Ketik pesan..."
          style={{
            flex: 1, background: '#F3F4F6', border: 'none',
            borderRadius: 22, padding: '12px 16px',
            fontSize: 14, color: '#1F2937', fontFamily: 'var(--font)',
          }}
        />
        <button
          onClick={() => sendMessage()}
          disabled={!input.trim() || loading}
          style={{
            background: input.trim() && !loading ? 'linear-gradient(135deg, #7C3AED, #9F67F7)' : '#E5E7EB',
            border: 'none', borderRadius: '50%',
            width: 44, height: 44,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: input.trim() && !loading ? 'pointer' : 'default',
            transition: 'all 0.2s',
            flexShrink: 0,
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22,2 15,22 11,13 2,9"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
