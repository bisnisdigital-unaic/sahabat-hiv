import React from 'react';

const RobotIcon = () => (
  <svg width="72" height="72" viewBox="0 0 72 72" fill="none">
    <circle cx="36" cy="36" r="36" fill="#EDE9FE"/>
    <rect x="20" y="26" width="32" height="26" rx="8" fill="#7C3AED"/>
    <rect x="24" y="30" width="10" height="8" rx="4" fill="white"/>
    <rect x="38" y="30" width="10" height="8" rx="4" fill="white"/>
    <circle cx="29" cy="34" r="3" fill="#7C3AED"/>
    <circle cx="43" cy="34" r="3" fill="#7C3AED"/>
    <path d="M28 44 Q36 50 44 44" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
    <rect x="33" y="18" width="6" height="10" rx="3" fill="#7C3AED"/>
    <circle cx="36" cy="17" r="3" fill="#EC4899"/>
    <rect x="14" y="32" width="6" height="12" rx="3" fill="#7C3AED"/>
    <rect x="52" y="32" width="6" height="12" rx="3" fill="#7C3AED"/>
    <rect x="28" y="52" width="6" height="10" rx="3" fill="#7C3AED"/>
    <rect x="38" y="52" width="6" height="10" rx="3" fill="#7C3AED"/>
  </svg>
);

const FeatureCard = ({ icon, title, subtitle, color, bg, onClick }) => (
  <button
    onClick={onClick}
    style={{
      background: bg,
      borderRadius: 16,
      padding: '20px 16px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8,
      border: 'none',
      cursor: 'pointer',
      transition: 'transform 0.15s, box-shadow 0.15s',
      boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
    }}
    onMouseDown={e => e.currentTarget.style.transform = 'scale(0.96)'}
    onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
    onTouchStart={e => e.currentTarget.style.transform = 'scale(0.96)'}
    onTouchEnd={e => e.currentTarget.style.transform = 'scale(1)'}
  >
    <span style={{ fontSize: 28 }}>{icon}</span>
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: 13, fontWeight: 700, color, lineHeight: 1.3 }}>{title}</div>
      {subtitle && <div style={{ fontSize: 11, color, opacity: 0.7, marginTop: 2 }}>{subtitle}</div>}
    </div>
  </button>
);

export default function HomePage({ onNavigate }) {
  return (
    <div style={{ minHeight: '100vh', background: '#fff' }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #7C3AED 0%, #9F67F7 100%)',
        padding: '52px 20px 28px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -30, right: -30,
          width: 120, height: 120, borderRadius: '50%',
          background: 'rgba(255,255,255,0.08)'
        }}/>
        <div style={{
          position: 'absolute', bottom: -20, left: -20,
          width: 80, height: 80, borderRadius: '50%',
          background: 'rgba(255,255,255,0.06)'
        }}/>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 20 }}>❤️</span>
            <span style={{ fontSize: 16, fontWeight: 800, color: '#fff' }}>SAHABAT AI HIV</span>
          </div>
          <button style={{ background: 'rgba(255,255,255,0.2)', border: 'none', borderRadius: 12, padding: '8px 10px', cursor: 'pointer' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>
            </svg>
          </button>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <RobotIcon />
          <div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', marginBottom: 2 }}>Hai, aku</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', lineHeight: 1.2 }}>Sahabat AI HIV 👋</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)', marginTop: 6, lineHeight: 1.5, maxWidth: 180 }}>
              Aku di sini untuk menemanimu mengenal HIV, cek risiko, dan menjaga kesehatanmu.
            </div>
          </div>
        </div>
      </div>

      {/* Feature Grid */}
      <div style={{ padding: '20px 16px', background: '#fff' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
          <FeatureCard
            icon="💬"
            title="Chat AI"
            subtitle="Tanya HIV"
            color="#7C3AED"
            bg="#EDE9FE"
            onClick={() => onNavigate('chat')}
          />
          <FeatureCard
            icon="🛡️"
            title="Cek Risiko"
            subtitle="HIV"
            color="#EC4899"
            bg="#FCE7F3"
            onClick={() => onNavigate('screening')}
          />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <FeatureCard
            icon="📚"
            title="Belajar HIV"
            subtitle="(Literasi)"
            color="#10B981"
            bg="#D1FAE5"
            onClick={() => onNavigate('literasi')}
          />
          <FeatureCard
            icon="📍"
            title="Cari Tempat"
            subtitle="Tes HIV"
            color="#3B82F6"
            bg="#DBEAFE"
            onClick={() => onNavigate('lokasi')}
          />
        </div>

        {/* Privacy Banner */}
        <div style={{
          marginTop: 16,
          background: 'linear-gradient(135deg, #F5F3FF, #FDF2F8)',
          borderRadius: 14,
          padding: '14px 18px',
          textAlign: 'center',
          border: '1px solid #EDE9FE',
        }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#7C3AED' }}>
            🔒 Privat • Aman • Tanpa Judgement
          </div>
          <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 3 }}>Semua data kamu dirahasiakan.</div>
        </div>

        {/* Fitur Utama */}
        <div style={{ marginTop: 24 }}>
          <div style={{ fontSize: 16, fontWeight: 800, color: '#1F2937', marginBottom: 14 }}>Fitur Utama</div>
          {[
            { icon: '🤖', text: 'AI Chatbot 24/7' },
            { icon: '✅', text: 'Self-Screening Risiko HIV' },
            { icon: '📖', text: 'Materi Edukasi Interaktif' },
            { icon: '🎯', text: 'Hasil & Rekomendasi Personal' },
            { icon: '📍', text: 'Lokasi Tes HIV Terdekat' },
            { icon: '🔒', text: 'Privat, Aman & Terpercaya' },
          ].map((f, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 0',
              borderBottom: i < 5 ? '1px solid #F3F4F6' : 'none',
            }}>
              <span style={{ fontSize: 18 }}>{f.icon}</span>
              <span style={{ fontSize: 14, color: '#374151' }}>{f.text}</span>
            </div>
          ))}
        </div>

        {/* Footer CTA */}
        <div style={{
          marginTop: 24,
          background: 'linear-gradient(135deg, #7C3AED, #EC4899)',
          borderRadius: 16,
          padding: '20px',
          textAlign: 'center',
          color: '#fff',
        }}>
          <div style={{ fontSize: 15, fontWeight: 800, lineHeight: 1.4 }}>
            Kenali Risiko<br/>Lindungi Diri<br/>Tes HIV, Hidup Pasti!
          </div>
          <div style={{ fontSize: 24, marginTop: 8 }}>🎀</div>
        </div>

        <div style={{ marginTop: 16, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {[
            { icon: '🔒', label: 'Privat & Aman', sub: 'Data kamu dirahasiakan' },
            { icon: '🧬', label: 'Berbasis Sains', sub: 'Informasi akurat' },
            { icon: '📱', label: 'Mudah Digunakan', sub: 'Desain sederhana' },
            { icon: '🎁', label: 'Gratis', sub: 'Akses tanpa biaya' },
          ].map((b, i) => (
            <div key={i} style={{
              flex: '1 1 calc(50% - 4px)',
              background: '#F9FAFB',
              borderRadius: 12,
              padding: '10px 12px',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
            }}>
              <span style={{ fontSize: 16 }}>{b.icon}</span>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#374151' }}>{b.label}</div>
                <div style={{ fontSize: 10, color: '#9CA3AF' }}>{b.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
