import React, { useState } from 'react';

const ARTICLES = [
  {
    id: 1,
    title: 'Apa itu HIV?',
    category: 'Dasar',
    icon: '🔬',
    color: '#7C3AED',
    bg: '#EDE9FE',
    content: `HIV (Human Immunodeficiency Virus) adalah virus yang menyerang sistem kekebalan tubuh, khususnya sel CD4 (sel T). Tanpa pengobatan, HIV dapat berkembang menjadi AIDS.

**HIV BUKAN berarti:**
• Vonis mati - dengan ARV, ODHIV bisa hidup normal
• Langsung AIDS - butuh waktu bertahun-tahun
• Hanya menyerang kelompok tertentu - siapapun bisa terinfeksi

**Fakta penting:**
HIV TIDAK menular melalui:
• Pelukan, ciuman pipi, atau jabat tangan
• Berbagi makanan atau minuman
• Toilet umum atau kolam renang
• Nyamuk atau serangga lain

HIV MENULAR melalui:
• Darah yang terinfeksi
• Hubungan seksual tanpa kondom
• Jarum suntik yang dipakai bersama
• Dari ibu ke bayi saat kehamilan/menyusui`,
  },
  {
    id: 2,
    title: 'Cara Penularan HIV',
    category: 'Penularan',
    icon: '⚡',
    color: '#EC4899',
    bg: '#FCE7F3',
    content: `HIV hanya ada dalam cairan tubuh tertentu dari orang yang terinfeksi HIV.

**Cairan yang bisa menularkan HIV:**
• Darah
• Air mani (semen)
• Cairan vagina/rektal
• ASI (Air Susu Ibu)

**Cara penularan utama:**
1. Hubungan seksual tanpa kondom (anal, vaginal, oral)
2. Berbagi jarum suntik atau alat suntik
3. Dari ibu ke bayi (kehamilan, persalinan, menyusui)
4. Transfusi darah yang tidak diskrining

**Risiko tertinggi:**
• Hubungan seksual anal tanpa kondom
• Berbagi jarum suntik dengan ODHIV
• Tidak menggunakan profilaksis (PrEP/PEP)

Ingat: Kondom yang digunakan dengan benar sangat efektif mencegah penularan HIV!`,
  },
  {
    id: 3,
    title: 'Cara Mencegah HIV',
    category: 'Pencegahan',
    icon: '🛡️',
    color: '#10B981',
    bg: '#D1FAE5',
    content: `Pencegahan HIV sangat efektif dan bisa dilakukan oleh siapapun.

**A-B-C-D-E Pencegahan HIV:**
• A (Abstinence) - Tidak melakukan hubungan seksual
• B (Be faithful) - Setia pada satu pasangan
• C (Condom) - Gunakan kondom yang benar
• D (Drug) - Hindari penggunaan narkoba
• E (Education) - Edukasi diri tentang HIV

**PrEP (Pre-Exposure Prophylaxis):**
Obat yang diminum SEBELUM terpapar HIV. Efektivitas >99% jika digunakan dengan benar. Tersedia di klinik VCT dan beberapa puskesmas.

**PEP (Post-Exposure Prophylaxis):**
Obat darurat yang diminum dalam 72 jam SETELAH terpapar HIV. Harus diminum selama 28 hari.

**Pencegahan lainnya:**
• Tes HIV rutin (minimal 1x setahun jika aktif seksual)
• Gunakan jarum suntik baru/steril
• Tes dan obati IMS lainnya`,
  },
  {
    id: 4,
    title: 'Hidup Sehat dengan HIV',
    category: 'ODHIV',
    icon: '💚',
    color: '#3B82F6',
    bg: '#DBEAFE',
    content: `Orang dengan HIV (ODHIV) bisa hidup sehat, produktif, dan berkualitas dengan pengobatan yang tepat.

**Terapi ARV (Antiretroviral):**
• ARV bukan obat penyembuh, tapi menekan virus
• Diminum setiap hari, seumur hidup
• Jika konsisten, viral load bisa UNDETECTABLE
• UNDETECTABLE = tidak dapat menularkan HIV (U=U)

**Menjaga kesehatan ODHIV:**
• Minum ARV setiap hari tanpa skip
• Kontrol rutin ke dokter
• Makan bergizi dan seimbang
• Olahraga teratur
• Cukup istirahat
• Hindari alkohol dan rokok
• Kelola stres dengan baik

**Hak ODHIV:**
• Berhak mendapat layanan kesehatan yang sama
• Rahasia medis dijaga
• Tidak boleh didiskriminasi di tempat kerja
• ARV tersedia GRATIS di faskes pemerintah`,
  },
  {
    id: 5,
    title: 'PrEP dan PEP',
    category: 'Pencegahan',
    icon: '💊',
    color: '#F59E0B',
    bg: '#FEF3C7',
    content: `PrEP dan PEP adalah obat pencegahan HIV yang sangat efektif.

**PrEP (Pre-Exposure Prophylaxis):**
Untuk siapa: Orang berisiko tinggi yang BELUM terinfeksi HIV
Kapan: Sebelum terpapar risiko
Cara: Diminum rutin setiap hari
Efektivitas: >99%
Di mana: Klinik VCT, RSUD, beberapa Puskesmas

Syarat PrEP:
• Status HIV negatif
• Fungsi ginjal normal
• Tidak ada hepatitis B aktif
• Komitmen minum obat rutin

**PEP (Post-Exposure Prophylaxis):**
Untuk siapa: Setelah paparan HIV yang tidak sengaja
Kapan: Harus dimulai dalam 72 jam (3 hari) setelah paparan
Cara: Diminum 28 hari penuh
Efektivitas: 80-85%

Situasi PEP:
• Kondom bocor/putus dengan pasangan ODHIV
• Tertusuk jarum yang dipakai ODHIV
• Korban kekerasan seksual

⚠️ PEP BUKAN KB darurat, gunakan hanya untuk situasi darurat!`,
  },
  {
    id: 6,
    title: 'Tes HIV: Kapan dan Di Mana?',
    category: 'Tes HIV',
    icon: '🔍',
    color: '#6366F1',
    bg: '#EEF2FF',
    content: `Tes HIV adalah satu-satunya cara mengetahui status HIV kamu.

**Siapa yang harus tes HIV:**
• Aktif secara seksual (setahun sekali)
• Pasangan berubah-ubah
• Pernah berbagi jarum suntik
• Hamil (wajib tes)
• Pasangan ODHIV
• Pernah mengalami gejala mirip HIV

**Jenis Tes HIV:**
1. Rapid Test - hasil 30 menit, tersedia di Puskesmas
2. ELISA - lebih akurat, hasil 1-2 hari
3. HIV RNA/PCR - untuk bayi atau window period

**Window Period:**
Periode dimana virus belum terdeteksi meski sudah terinfeksi (14-90 hari tergantung jenis tes)

**Layanan Tes HIV:**
• Puskesmas (gratis)
• Klinik VCT (konseling + tes)
• RSUD/RS Pemerintah (gratis)
• Lembaga swadaya masyarakat

**Hasil Tes HIV:**
• Reaktif/Positif: langsung diarahkan ke ARV
• Non-reaktif/Negatif: tetap jaga diri
• Semua hasil RAHASIA!`,
  },
];

const TOPICS = [
  { icon: '🧬', title: 'Cara Penularan HIV', id: 2 },
  { icon: '🛡️', title: 'Cara Mencegah HIV', id: 3 },
  { icon: '💚', title: 'Hidup Sehat dengan HIV', id: 4 },
  { icon: '💊', title: 'PrEP dan PEP', id: 5 },
  { icon: '🔍', title: 'Tes HIV: Kapan dan Di Mana?', id: 6 },
];

function ArticleView({ article, onBack }) {
  const lines = article.content.split('\n');
  return (
    <div style={{ minHeight: '100vh', background: '#fff' }}>
      <div style={{
        background: `linear-gradient(135deg, ${article.color}, ${article.color}CC)`,
        padding: '52px 20px 24px',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <button onClick={onBack} style={{
          background: 'rgba(255,255,255,0.2)', border: 'none',
          borderRadius: 10, padding: '8px 10px', cursor: 'pointer',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', marginBottom: 2 }}>{article.category}</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>{article.title}</div>
        </div>
      </div>
      <div style={{ padding: '20px' }}>
        {lines.map((line, i) => {
          if (line.startsWith('**') && line.endsWith('**')) {
            return <div key={i} style={{ fontSize: 15, fontWeight: 800, color: '#1F2937', margin: '16px 0 8px' }}>
              {line.slice(2, -2)}
            </div>;
          }
          if (line.startsWith('• ')) {
            return <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
              <span style={{ color: article.color, fontWeight: 700, flexShrink: 0 }}>•</span>
              <span style={{ fontSize: 14, color: '#374151', lineHeight: 1.6 }}>{line.slice(2)}</span>
            </div>;
          }
          if (/^\d\./.test(line)) {
            return <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
              <span style={{ color: article.color, fontWeight: 700, flexShrink: 0 }}>{line[0]}.</span>
              <span style={{ fontSize: 14, color: '#374151', lineHeight: 1.6 }}>{line.slice(2)}</span>
            </div>;
          }
          if (line.startsWith('⚠️')) {
            return <div key={i} style={{
              background: '#FEF3C7', borderRadius: 12, padding: '12px 14px',
              fontSize: 13, color: '#92400E', marginTop: 12, lineHeight: 1.6,
            }}>{line}</div>;
          }
          if (line === '') return <div key={i} style={{ height: 6 }} />;
          return <p key={i} style={{ fontSize: 14, color: '#374151', lineHeight: 1.7, marginBottom: 6 }}>{line}</p>;
        })}
      </div>
    </div>
  );
}

export default function LiterasiPage({ onBack }) {
  const [activeArticle, setActiveArticle] = useState(null);

  if (activeArticle) {
    return <ArticleView article={activeArticle} onBack={() => setActiveArticle(null)} />;
  }

  return (
    <div style={{ minHeight: '100vh', background: '#fff' }}>
      <div style={{
        background: 'linear-gradient(135deg, #10B981, #34D399)',
        padding: '52px 20px 24px',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <button onClick={onBack} style={{
          background: 'rgba(255,255,255,0.2)', border: 'none',
          borderRadius: 10, padding: '8px 10px', cursor: 'pointer',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <div style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>Belajar HIV (Literasi)</div>
      </div>

      <div style={{ padding: '20px' }}>
        {/* Topik Populer */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <span style={{ fontSize: 15, fontWeight: 800, color: '#1F2937' }}>Topik Populer</span>
          <span style={{ fontSize: 12, color: '#7C3AED', fontWeight: 600 }}>Lihat semua</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
          {ARTICLES.slice(0, 2).map(article => (
            <button
              key={article.id}
              onClick={() => setActiveArticle(article)}
              style={{
                background: article.bg, borderRadius: 16, padding: '16px',
                border: 'none', cursor: 'pointer', textAlign: 'left',
                transition: 'transform 0.15s',
              }}
              onMouseDown={e => e.currentTarget.style.transform = 'scale(0.96)'}
              onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
              onTouchStart={e => e.currentTarget.style.transform = 'scale(0.96)'}
              onTouchEnd={e => e.currentTarget.style.transform = 'scale(1)'}
            >
              <div style={{ fontSize: 28, marginBottom: 8 }}>{article.icon}</div>
              <div style={{ fontSize: 12, color: article.color, fontWeight: 700, marginBottom: 4 }}>{article.category}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#1F2937', lineHeight: 1.4 }}>{article.title}</div>
            </button>
          ))}
        </div>

        {/* Materi Lainnya */}
        <div style={{ fontSize: 15, fontWeight: 800, color: '#1F2937', marginBottom: 14 }}>Materi Lainnya</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {TOPICS.map((topic, i) => {
            const article = ARTICLES.find(a => a.id === topic.id);
            return (
              <button
                key={i}
                onClick={() => setActiveArticle(article)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 14,
                  padding: '14px 0',
                  background: 'none', border: 'none', cursor: 'pointer',
                  borderBottom: i < TOPICS.length - 1 ? '1px solid #F3F4F6' : 'none',
                  fontFamily: 'var(--font)',
                }}
              >
                <div style={{
                  width: 40, height: 40, borderRadius: 12,
                  background: '#F3F4F6',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 20, flexShrink: 0,
                }}>
                  {topic.icon}
                </div>
                <span style={{ flex: 1, fontSize: 14, fontWeight: 600, color: '#374151', textAlign: 'left' }}>
                  {topic.title}
                </span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2">
                  <path d="M9 18l6-6-6-6"/>
                </svg>
              </button>
            );
          })}
        </div>

        {/* Kuis */}
        <button style={{
          width: '100%', marginTop: 20,
          background: 'linear-gradient(135deg, #10B981, #34D399)',
          color: '#fff', border: 'none', borderRadius: 14,
          padding: '16px', fontSize: 15, fontWeight: 700,
          cursor: 'pointer', fontFamily: 'var(--font)',
        }}>
          🎯 Kuis Literasi HIV
        </button>
      </div>
    </div>
  );
}
