import React, { useState } from 'react';

const LOCATIONS = [
  {
    name: 'Puskesmas Cilacap Selatan I',
    address: 'Jl. Gatot Subroto No. 25, Cilacap',
    distance: '1.2 km',
    type: 'Puskesmas',
    phone: '(0282) 531234',
    hours: 'Senin-Jumat 08.00-14.00',
    services: ['Tes HIV', 'VCT', 'ARV'],
    open: true,
  },
  {
    name: 'Klinik VCT RSUD Cilacap',
    address: 'Jl. Rumah Sakit No. 1, Cilacap',
    distance: '2.5 km',
    type: 'Klinik VCT',
    phone: '(0282) 532345',
    hours: 'Senin-Sabtu 08.00-16.00',
    services: ['Tes HIV', 'VCT', 'ARV', 'PrEP', 'Konseling'],
    open: true,
  },
  {
    name: 'Puskesmas Kroya I',
    address: 'Jl. Raya Kroya No. 45, Kroya',
    distance: '9.3 km',
    type: 'Puskesmas',
    phone: '(0282) 494567',
    hours: 'Senin-Jumat 08.00-14.00',
    services: ['Tes HIV', 'VCT'],
    open: true,
  },
  {
    name: 'RS Pertamina Cilacap',
    address: 'Jl. MT Haryono No. 20, Cilacap',
    distance: '3.1 km',
    type: 'RS',
    phone: '(0282) 534678',
    hours: '24 Jam',
    services: ['Tes HIV', 'VCT', 'ARV', 'Rawat Inap'],
    open: true,
  },
  {
    name: 'Puskesmas Karangpucung',
    address: 'Jl. Raya Karangpucung No. 12',
    distance: '14.2 km',
    type: 'Puskesmas',
    phone: '(0282) 495789',
    hours: 'Senin-Jumat 08.00-14.00',
    services: ['Tes HIV'],
    open: false,
  },
];

const TYPE_COLORS = {
  'Puskesmas': { color: '#10B981', bg: '#D1FAE5' },
  'Klinik VCT': { color: '#7C3AED', bg: '#EDE9FE' },
  'RS': { color: '#3B82F6', bg: '#DBEAFE' },
};

const FILTERS = ['Semua', 'Puskesmas', 'Klinik VCT', 'RS'];

export default function LokasiPage({ onBack }) {
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('Semua');
  const [selectedLocation, setSelectedLocation] = useState(null);

  const filtered = LOCATIONS.filter(loc => {
    const matchSearch = loc.name.toLowerCase().includes(search.toLowerCase()) ||
      loc.address.toLowerCase().includes(search.toLowerCase());
    const matchFilter = activeFilter === 'Semua' || loc.type === activeFilter;
    return matchSearch && matchFilter;
  });

  if (selectedLocation) {
    const tc = TYPE_COLORS[selectedLocation.type] || { color: '#6B7280', bg: '#F3F4F6' };
    return (
      <div style={{ minHeight: '100vh', background: '#fff' }}>
        <div style={{
          background: 'linear-gradient(135deg, #3B82F6, #60A5FA)',
          padding: '52px 20px 24px',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <button onClick={() => setSelectedLocation(null)} style={{
            background: 'rgba(255,255,255,0.2)', border: 'none',
            borderRadius: 10, padding: '8px 10px', cursor: 'pointer',
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#fff' }}>Detail Fasilitas</div>
        </div>

        <div style={{ padding: 20 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            background: tc.bg, borderRadius: 20, padding: '4px 12px',
            marginBottom: 12,
          }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: tc.color, display: 'inline-block' }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: tc.color }}>{selectedLocation.type}</span>
          </div>
          <div style={{ fontSize: 20, fontWeight: 800, color: '#1F2937', marginBottom: 4 }}>{selectedLocation.name}</div>
          <div style={{ fontSize: 14, color: '#6B7280', marginBottom: 20 }}>{selectedLocation.address}</div>

          {[
            { icon: '📞', label: 'Telepon', value: selectedLocation.phone },
            { icon: '⏰', label: 'Jam Operasional', value: selectedLocation.hours },
            { icon: '📍', label: 'Jarak', value: selectedLocation.distance },
            { icon: '✅', label: 'Status', value: selectedLocation.open ? 'Buka Sekarang' : 'Tutup', valueColor: selectedLocation.open ? '#10B981' : '#EF4444' },
          ].map((item, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: 12,
              padding: '14px 0',
              borderBottom: i < 3 ? '1px solid #F3F4F6' : 'none',
            }}>
              <span style={{ fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
              <div>
                <div style={{ fontSize: 12, color: '#9CA3AF', marginBottom: 2 }}>{item.label}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: item.valueColor || '#1F2937' }}>{item.value}</div>
              </div>
            </div>
          ))}

          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 13, color: '#9CA3AF', marginBottom: 10 }}>Layanan Tersedia</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {selectedLocation.services.map((s, i) => (
                <span key={i} style={{
                  background: '#EDE9FE', color: '#7C3AED',
                  borderRadius: 20, padding: '6px 14px',
                  fontSize: 12, fontWeight: 700,
                }}>{s}</span>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
            <a
              href={`tel:${selectedLocation.phone.replace(/[^0-9]/g, '')}`}
              style={{
                flex: 1, background: '#fff',
                border: '2px solid #3B82F6', borderRadius: 14,
                padding: '14px', fontSize: 14, fontWeight: 700,
                color: '#3B82F6', textAlign: 'center', textDecoration: 'none',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}
            >
              📞 Hubungi
            </a>
            <a
              href={`https://maps.google.com/?q=${encodeURIComponent(selectedLocation.name + ' ' + selectedLocation.address)}`}
              target="_blank"
              rel="noreferrer"
              style={{
                flex: 1,
                background: 'linear-gradient(135deg, #3B82F6, #60A5FA)',
                border: 'none', borderRadius: 14,
                padding: '14px', fontSize: 14, fontWeight: 700,
                color: '#fff', textAlign: 'center', textDecoration: 'none',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}
            >
              🗺️ Peta
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: '#fff' }}>
      <div style={{
        background: 'linear-gradient(135deg, #3B82F6, #60A5FA)',
        padding: '52px 20px 20px',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <button onClick={onBack} style={{
          background: 'rgba(255,255,255,0.2)', border: 'none',
          borderRadius: 10, padding: '8px 10px', cursor: 'pointer',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <div style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>Cari Tempat Tes HIV</div>
      </div>

      <div style={{ padding: '16px' }}>
        {/* Search */}
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <svg style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }}
            width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Cari lokasi / nama fasilitas"
            style={{
              width: '100%', padding: '12px 14px 12px 40px',
              background: '#F3F4F6', border: 'none', borderRadius: 12,
              fontSize: 14, color: '#1F2937', fontFamily: 'var(--font)',
            }}
          />
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, overflowX: 'auto', paddingBottom: 4 }}>
          {FILTERS.map(f => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              style={{
                background: activeFilter === f ? '#3B82F6' : '#F3F4F6',
                color: activeFilter === f ? '#fff' : '#6B7280',
                border: 'none', borderRadius: 20, padding: '8px 16px',
                fontSize: 13, fontWeight: 600, cursor: 'pointer',
                fontFamily: 'var(--font)', whiteSpace: 'nowrap',
                transition: 'all 0.2s',
              }}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Map placeholder */}
        <div style={{
          background: '#EEF2FF', borderRadius: 16, height: 180,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 16, position: 'relative', overflow: 'hidden',
          border: '1px solid #DBEAFE',
        }}>
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg, #DBEAFE 0%, #EEF2FF 100%)' }} />
          <div style={{ textAlign: 'center', position: 'relative', zIndex: 1 }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>🗺️</div>
            <div style={{ fontSize: 13, color: '#3B82F6', fontWeight: 600 }}>Peta Interaktif</div>
            <div style={{ fontSize: 11, color: '#6B7280', marginTop: 2 }}>Menampilkan {filtered.length} fasilitas terdekat</div>
          </div>
          {/* Fake pins */}
          {['30%,40%', '55%,55%', '70%,35%'].map((pos, i) => (
            <div key={i} style={{
              position: 'absolute', left: pos.split(',')[0], top: pos.split(',')[1],
              transform: 'translate(-50%,-50%)',
            }}>
              <div style={{
                width: 24, height: 24, borderRadius: '50% 50% 50% 0',
                background: i === 0 ? '#EF4444' : '#3B82F6',
                transform: 'rotate(-45deg)',
                boxShadow: '0 2px 6px rgba(0,0,0,0.2)',
              }} />
            </div>
          ))}
        </div>

        {/* Location List */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {filtered.map((loc, i) => {
            const tc = TYPE_COLORS[loc.type] || { color: '#6B7280', bg: '#F3F4F6' };
            return (
              <button
                key={i}
                onClick={() => setSelectedLocation(loc)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 14,
                  padding: '14px 0',
                  background: 'none', border: 'none', cursor: 'pointer',
                  borderBottom: i < filtered.length - 1 ? '1px solid #F3F4F6' : 'none',
                  fontFamily: 'var(--font)', textAlign: 'left',
                }}
              >
                <div style={{
                  width: 44, height: 44, borderRadius: 12,
                  background: tc.bg, display: 'flex', alignItems: 'center',
                  justifyContent: 'center', flexShrink: 0, fontSize: 22,
                }}>
                  {loc.type === 'Klinik VCT' ? '🏥' : loc.type === 'RS' ? '🏨' : '🏪'}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: '#1F2937', marginBottom: 2 }}>
                    {loc.name}
                  </div>
                  <div style={{ fontSize: 12, color: '#6B7280', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {loc.address}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                    <span style={{ fontSize: 11, color: loc.open ? '#10B981' : '#EF4444', fontWeight: 600 }}>
                      {loc.open ? '● Buka' : '● Tutup'}
                    </span>
                    <span style={{ fontSize: 11, color: '#9CA3AF' }}>• {loc.distance}</span>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                  <a
                    href={`tel:${loc.phone.replace(/[^0-9]/g, '')}`}
                    onClick={e => e.stopPropagation()}
                    style={{
                      width: 36, height: 36, borderRadius: 10,
                      background: '#EDE9FE', display: 'flex',
                      alignItems: 'center', justifyContent: 'center',
                      textDecoration: 'none',
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#7C3AED" strokeWidth="2">
                      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 0117 3.06h.18a2 2 0 012 2v3a2 2 0 01-1.37 1.87 16 16 0 00-6.82 6.83A2 2 0 0122 16.92z"/>
                    </svg>
                  </a>
                </div>
              </button>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '40px 20px' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
            <div style={{ fontSize: 15, fontWeight: 600, color: '#374151' }}>Tidak ditemukan</div>
            <div style={{ fontSize: 13, color: '#9CA3AF', marginTop: 4 }}>Coba kata kunci lain</div>
          </div>
        )}
      </div>
    </div>
  );
}
