export { NotifPage as default } from './OtherPages';
