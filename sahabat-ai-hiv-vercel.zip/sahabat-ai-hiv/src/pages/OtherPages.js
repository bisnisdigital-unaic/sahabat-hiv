import React from 'react';

export function HistoryPage() {
  const history = [
    { date: '03 Mei 2026', type: 'Skrining', result: 'Risiko Sedang', icon: '🛡️', color: '#F59E0B', bg: '#FEF3C7' },
    { date: '02 Mei 2026', type: 'Chat AI', result: 'Tentang PrEP', icon: '💬', color: '#7C3AED', bg: '#EDE9FE' },
    { date: '01 Mei 2026', type: 'Literasi', result: 'Cara Penularan HIV', icon: '📚', color: '#10B981', bg: '#D1FAE5' },
    { date: '28 Apr 2026', type: 'Chat AI', result: 'Gejala HIV', icon: '💬', color: '#7C3AED', bg: '#EDE9FE' },
    { date: '25 Apr 2026', type: 'Lokasi', result: 'Klinik VCT RSUD Cilacap', icon: '📍', color: '#3B82F6', bg: '#DBEAFE' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#fff' }}>
      <div style={{
        background: 'linear-gradient(135deg, #7C3AED, #9F67F7)',
        padding: '52px 20px 20px',
      }}>
        <div style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>Riwayat Aktivitas</div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 4 }}>{history.length} aktivitas tercatat</div>
      </div>
      <div style={{ padding: '16px 20px' }}>
        {history.map((item, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 0',
            borderBottom: i < history.length - 1 ? '1px solid #F3F4F6' : 'none',
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12,
              background: item.bg, display: 'flex',
              alignItems: 'center', justifyContent: 'center',
              fontSize: 22, flexShrink: 0,
            }}>
              {item.icon}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#1F2937' }}>{item.type}</div>
              <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>{item.result}</div>
            </div>
            <div style={{ fontSize: 11, color: '#9CA3AF', textAlign: 'right' }}>{item.date}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function NotifPage() {
  const notifs = [
    { title: 'Pengingat Tes HIV', body: 'Sudah 3 bulan sejak kamu terakhir tes HIV. Yuk tes sekarang!', time: '1 jam lalu', icon: '🔬', read: false },
    { title: 'Konten Baru', body: 'Artikel baru: "Mitos vs Fakta HIV" telah tersedia', time: '1 hari lalu', icon: '📖', read: false },
    { title: 'Reminder Konseling', body: 'Jadwal konseling online kamu hari ini pukul 14.00', time: '2 hari lalu', icon: '💬', read: true },
    { title: 'Tips Kesehatan', body: 'Gunakan kondom dengan benar untuk perlindungan optimal', time: '3 hari lalu', icon: '🛡️', read: true },
    { title: 'Update Aplikasi', body: 'Fitur baru tersedia: Lokasi Tes HIV terdekat yang diperbarui', time: '1 minggu lalu', icon: '✨', read: true },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#fff' }}>
      <div style={{
        background: 'linear-gradient(135deg, #7C3AED, #9F67F7)',
        padding: '52px 20px 20px',
      }}>
        <div style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>Notifikasi</div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 4 }}>
          {notifs.filter(n => !n.read).length} notifikasi belum dibaca
        </div>
      </div>
      <div style={{ padding: '8px 0' }}>
        {notifs.map((notif, i) => (
          <div key={i} style={{
            display: 'flex', gap: 14,
            padding: '16px 20px',
            background: notif.read ? '#fff' : '#F5F3FF',
            borderBottom: '1px solid #F3F4F6',
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12,
              background: notif.read ? '#F3F4F6' : '#EDE9FE',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 22, flexShrink: 0,
            }}>{notif.icon}</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ fontSize: 14, fontWeight: notif.read ? 500 : 700, color: '#1F2937' }}>{notif.title}</div>
                {!notif.read && (
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#7C3AED', flexShrink: 0, marginTop: 4 }} />
                )}
              </div>
              <div style={{ fontSize: 13, color: '#6B7280', marginTop: 3, lineHeight: 1.5 }}>{notif.body}</div>
              <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 4 }}>{notif.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const stats = [
    { label: 'Sesi Chat', value: '12', icon: '💬' },
    { label: 'Skrining', value: '3', icon: '🛡️' },
    { label: 'Artikel', value: '8', icon: '📚' },
  ];

  const menuItems = [
    { icon: '👤', label: 'Edit Profil', color: '#7C3AED' },
    { icon: '🔔', label: 'Pengaturan Notifikasi', color: '#F59E0B' },
    { icon: '🔒', label: 'Privasi & Keamanan', color: '#10B981' },
    { icon: '❓', label: 'Bantuan & FAQ', color: '#3B82F6' },
    { icon: '📞', label: 'Hubungi Kami', color: '#EC4899' },
    { icon: '📋', label: 'Tentang Aplikasi', color: '#6B7280' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#F9FAFB' }}>
      <div style={{
        background: 'linear-gradient(135deg, #7C3AED, #9F67F7)',
        padding: '52px 20px 30px',
        textAlign: 'center',
      }}>
        <div style={{
          width: 80, height: 80, borderRadius: '50%',
          background: 'rgba(255,255,255,0.2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 12px', fontSize: 36,
        }}>👤</div>
        <div style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>Pengguna Anonim</div>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 4 }}>Bergabung sejak Mei 2026</div>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          background: 'rgba(255,255,255,0.2)', borderRadius: 20,
          padding: '6px 14px', marginTop: 10,
        }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#4ADE80', display: 'inline-block' }} />
          <span style={{ fontSize: 12, color: '#fff', fontWeight: 600 }}>Akun Terlindungi</span>
        </div>
      </div>

      {/* Stats */}
      <div style={{
        display: 'flex', gap: 0, background: '#fff',
        borderBottom: '1px solid #F3F4F6',
      }}>
        {stats.map((s, i) => (
          <div key={i} style={{
            flex: 1, textAlign: 'center', padding: '16px 8px',
            borderRight: i < stats.length - 1 ? '1px solid #F3F4F6' : 'none',
          }}>
            <div style={{ fontSize: 22, marginBottom: 2 }}>{s.icon}</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: '#7C3AED' }}>{s.value}</div>
            <div style={{ fontSize: 11, color: '#9CA3AF' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Menu */}
      <div style={{ background: '#fff', marginTop: 12 }}>
        {menuItems.map((item, i) => (
          <button key={i} style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 14,
            padding: '16px 20px',
            background: 'none', border: 'none',
            borderBottom: i < menuItems.length - 1 ? '1px solid #F3F4F6' : 'none',
            cursor: 'pointer', fontFamily: 'var(--font)', textAlign: 'left',
          }}>
            <div style={{
              width: 40, height: 40, borderRadius: 12,
              background: `${item.color}15`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 20,
            }}>{item.icon}</div>
            <span style={{ flex: 1, fontSize: 14, fontWeight: 600, color: '#374151' }}>{item.label}</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2">
              <path d="M9 18l6-6-6-6"/>
            </svg>
          </button>
        ))}
      </div>

      <div style={{ padding: '20px', textAlign: 'center' }}>
        <button style={{
          background: '#FEE2E2', color: '#EF4444',
          border: 'none', borderRadius: 12, padding: '12px 24px',
          fontSize: 14, fontWeight: 700, cursor: 'pointer',
          fontFamily: 'var(--font)',
        }}>
          🚪 Keluar dari Akun
        </button>
        <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 16 }}>
          SAHABAT AI HIV v1.0.0<br/>
          © 2026 • Privat & Aman • Gratis
        </div>
      </div>
    </div>
  );
}
