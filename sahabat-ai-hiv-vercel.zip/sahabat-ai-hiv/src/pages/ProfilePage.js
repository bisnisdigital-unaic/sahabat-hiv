export { default } from './OtherPages';
