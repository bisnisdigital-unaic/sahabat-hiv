import React, { useState } from 'react';

const QUESTIONS = [
  {
    id: 1,
    question: 'Dalam 12 bulan terakhir, pernahkah Anda melakukan hubungan seksual tanpa menggunakan kondom?',
    options: ['Tidak pernah', 'Pernah, dengan 1 pasangan', 'Pernah, lebih dari 1 pasangan'],
    scores: [0, 1, 3],
  },
  {
    id: 2,
    question: 'Apakah Anda pernah menggunakan jarum suntik bersama orang lain?',
    options: ['Tidak pernah', 'Pernah sekali', 'Sering / lebih dari sekali'],
    scores: [0, 2, 4],
  },
  {
    id: 3,
    question: 'Apakah Anda mengetahui status HIV pasangan seksual Anda?',
    options: ['Ya, dan negatif', 'Tidak tahu', 'Ya, dan positif'],
    scores: [0, 1, 3],
  },
  {
    id: 4,
    question: 'Apakah Anda pernah melakukan tes HIV sebelumnya?',
    options: ['Ya, dalam 1 tahun terakhir', 'Ya, lebih dari 1 tahun lalu', 'Belum pernah'],
    scores: [0, 1, 1],
  },
  {
    id: 5,
    question: 'Apakah Anda mengalami gejala seperti demam, ruam kulit, atau pembengkakan kelenjar tanpa sebab jelas dalam 3 bulan terakhir?',
    options: ['Tidak', 'Ya, gejala ringan', 'Ya, gejala berat'],
    scores: [0, 1, 2],
  },
  {
    id: 6,
    question: 'Apakah Anda pernah menerima transfusi darah atau transplantasi organ?',
    options: ['Tidak', 'Ya, dengan prosedur yang aman', 'Ya, tidak yakin keamanannya'],
    scores: [0, 0, 2],
  },
  {
    id: 7,
    question: 'Apakah Anda atau pasangan Anda pernah didiagnosis IMS (Infeksi Menular Seksual) lainnya?',
    options: ['Tidak', 'Tidak yakin', 'Ya'],
    scores: [0, 1, 2],
  },
];

const getRiskLevel = (score) => {
  if (score <= 2) return { level: 'RENDAH', color: '#10B981', bg: '#D1FAE5', emoji: '✅', desc: 'Risiko kamu tergolong rendah. Tetap jaga diri dengan perilaku seksual yang aman!' };
  if (score <= 6) return { level: 'SEDANG', color: '#F59E0B', bg: '#FEF3C7', emoji: '⚠️', desc: 'Ada beberapa perilaku yang dapat meningkatkan risiko. Disarankan untuk lebih berhati-hati dan melakukan tes HIV.' };
  return { level: 'TINGGI', color: '#EF4444', bg: '#FEE2E2', emoji: '🚨', desc: 'Kamu memiliki faktor risiko yang signifikan. Sangat disarankan untuk segera melakukan tes HIV di fasilitas kesehatan terdekat.' };
};

export default function ScreeningPage({ onBack }) {
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [selected, setSelected] = useState(null);
  const [showResult, setShowResult] = useState(false);

  const question = QUESTIONS[current];
  const progress = ((current) / QUESTIONS.length) * 100;

  const handleSelect = (optIdx) => {
    setSelected(optIdx);
  };

  const handleNext = () => {
    if (selected === null) return;
    const newAnswers = { ...answers, [question.id]: question.scores[selected] };
    setAnswers(newAnswers);

    if (current < QUESTIONS.length - 1) {
      setCurrent(current + 1);
      setSelected(null);
    } else {
      setShowResult(true);
    }
  };

  const totalScore = Object.values(answers).reduce((a, b) => a + b, 0);
  const risk = getRiskLevel(totalScore);

  const restart = () => {
    setCurrent(0);
    setAnswers({});
    setSelected(null);
    setShowResult(false);
  };

  if (showResult) {
    return (
      <div style={{ minHeight: '100vh', background: '#fff' }}>
        <div style={{
          background: 'linear-gradient(135deg, #EC4899, #F472B6)',
          padding: '52px 20px 24px',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <button onClick={onBack} style={{
            background: 'rgba(255,255,255,0.2)', border: 'none',
            borderRadius: 10, padding: '8px 10px', cursor: 'pointer',
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>Hasil Penilaian Risiko</div>
        </div>

        <div style={{ padding: 20 }}>
          <div style={{
            background: risk.bg, borderRadius: 16, padding: '24px 20px',
            textAlign: 'center', marginBottom: 20,
            border: `2px solid ${risk.color}22`,
          }}>
            <div style={{ fontSize: 13, color: '#6B7280', marginBottom: 6 }}>Kategori Risiko Anda</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: risk.color }}>{risk.level}</div>
            <div style={{ fontSize: 28, marginTop: 8 }}>{risk.emoji}</div>
            <div style={{ fontSize: 13, color: '#374151', marginTop: 12, lineHeight: 1.6 }}>{risk.desc}</div>
          </div>

          <div style={{ fontSize: 15, fontWeight: 700, color: '#1F2937', marginBottom: 12 }}>Rekomendasi untuk Anda:</div>
          {[
            { icon: '🔬', text: 'Lakukan tes HIV dalam 1 bulan ke depan' },
            { icon: '🛡️', text: 'Gunakan kondom dengan benar saat berhubungan seksual' },
            { icon: '💉', text: 'Hindari berbagi jarum suntik' },
            { icon: '💬', text: 'Konseling online tersedia di sini' },
          ].map((r, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '12px 0',
              borderBottom: i < 3 ? '1px solid #F3F4F6' : 'none',
            }}>
              <span style={{ fontSize: 18 }}>{r.icon}</span>
              <span style={{ fontSize: 14, color: '#374151' }}>{r.text}</span>
            </div>
          ))}

          <button style={{
            width: '100%', marginTop: 20,
            background: 'linear-gradient(135deg, #EC4899, #F472B6)',
            color: '#fff', border: 'none', borderRadius: 14,
            padding: '16px', fontSize: 15, fontWeight: 700,
            cursor: 'pointer', fontFamily: 'var(--font)',
          }}
            onClick={() => onBack()}
          >
            📍 Cari Tempat Tes HIV
          </button>

          <button style={{
            width: '100%', marginTop: 12,
            background: '#fff', color: '#EC4899',
            border: '2px solid #EC4899', borderRadius: 14,
            padding: '14px', fontSize: 14, fontWeight: 600,
            cursor: 'pointer', fontFamily: 'var(--font)',
          }}
            onClick={restart}
          >
            Ulangi Skrining
          </button>

          <div style={{
            marginTop: 20, textAlign: 'center',
            fontSize: 11, color: '#9CA3AF', lineHeight: 1.5,
          }}>
            ⚠️ Hasil ini bukan diagnosis medis.<br/>
            Untuk hasil pasti, lakukan tes HIV di fasilitas kesehatan.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: '#fff' }}>
      <div style={{
        background: 'linear-gradient(135deg, #EC4899, #F472B6)',
        padding: '52px 20px 20px',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <button onClick={onBack} style={{
          background: 'rgba(255,255,255,0.2)', border: 'none',
          borderRadius: 10, padding: '8px 10px', cursor: 'pointer',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>Cek Risiko HIV</div>
        </div>
        <button onClick={onBack} style={{
          background: 'rgba(255,255,255,0.2)', border: 'none',
          borderRadius: 8, padding: '6px 12px',
          fontSize: 12, fontWeight: 600, color: '#fff',
          cursor: 'pointer', fontFamily: 'var(--font)',
        }}>Keluar</button>
      </div>

      <div style={{ padding: '20px 20px 0' }}>
        {/* Progress */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
          <div style={{ flex: 1, background: '#F3F4F6', borderRadius: 4, height: 8 }}>
            <div style={{
              width: `${progress}%`, height: '100%',
              background: 'linear-gradient(135deg, #EC4899, #F472B6)',
              borderRadius: 4, transition: 'width 0.4s',
            }} />
          </div>
          <span style={{ fontSize: 13, fontWeight: 700, color: '#EC4899', minWidth: 32 }}>
            {current + 1}/{QUESTIONS.length}
          </span>
        </div>

        <div style={{ fontSize: 16, fontWeight: 700, color: '#1F2937', lineHeight: 1.5, marginBottom: 24 }}>
          {question.question}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {question.options.map((opt, i) => (
            <button
              key={i}
              onClick={() => handleSelect(i)}
              style={{
                display: 'flex', alignItems: 'center', gap: 14,
                padding: '16px 18px',
                background: selected === i ? '#FCE7F3' : '#F9FAFB',
                border: selected === i ? '2px solid #EC4899' : '2px solid #F3F4F6',
                borderRadius: 14, cursor: 'pointer', textAlign: 'left',
                fontFamily: 'var(--font)',
                transition: 'all 0.15s',
              }}
            >
              <div style={{
                width: 22, height: 22, borderRadius: '50%',
                border: selected === i ? '2px solid #EC4899' : '2px solid #D1D5DB',
                background: selected === i ? '#EC4899' : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}>
                {selected === i && (
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3">
                    <polyline points="20,6 9,17 4,12"/>
                  </svg>
                )}
              </div>
              <span style={{ fontSize: 14, color: selected === i ? '#BE185D' : '#374151', fontWeight: selected === i ? 600 : 400 }}>
                {opt}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: '24px 20px' }}>
        <button
          onClick={handleNext}
          disabled={selected === null}
          style={{
            width: '100%',
            background: selected !== null ? 'linear-gradient(135deg, #EC4899, #F472B6)' : '#E5E7EB',
            color: selected !== null ? '#fff' : '#9CA3AF',
            border: 'none', borderRadius: 14,
            padding: '16px', fontSize: 15, fontWeight: 700,
            cursor: selected !== null ? 'pointer' : 'default',
            fontFamily: 'var(--font)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            transition: 'all 0.2s',
          }}
        >
          {current < QUESTIONS.length - 1 ? 'Selanjutnya →' : 'Lihat Hasil →'}
        </button>
      </div>
    </div>
  );
}
